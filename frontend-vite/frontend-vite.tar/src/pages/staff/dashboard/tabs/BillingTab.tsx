import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDashboard } from '../dashboardContext';
import { useDashboardCRUD } from '../../dashboard/useDashboardCRUD';
import { exportInvoicePdf } from '../../../../utils/invoicePdf';

export default function BillingTab() {
  const { t } = useTranslation();
  const [provider, setProvider] = useState<'mercadopago' | 'stripe'>('mercadopago');
  const { plan, invoices, settings, loadInvoices } = useDashboard();
  const { subscribeToPlan, handlePayInvoice } = useDashboardCRUD();

  return (
    <div className="glass-panel mt-24 p-24">
      <div className="flex-between gap-16 mb-18">
        <div>
          <h3 className="text-gradient m-0">{t('staffDashboard.billingTitle')}</h3>
          <p className="text-muted m-0 mt-6">{t('staffDashboard.billingDescription')}</p>
        </div>
        <button className="dash-btn dash-btn-success" onClick={() => loadInvoices()}>{t('staffDashboard.billingRefresh')}</button>
      </div>
      <div className="flex align-items-center gap-16 mb-18">
        <span className="text-muted">{t('staffDashboard.billingPaymentMethod')}</span>
        <select className="dash-input" style={{ maxWidth: 220 }} value={provider} onChange={e => setProvider(e.target.value as 'mercadopago' | 'stripe')}>
          <option value="mercadopago">Mercado Pago (UYU)</option>
          <option value="stripe">Stripe (USD)</option>
        </select>
      </div>
      {plan ? (
        <div className="glass-panel mb-20 p-20" style={{ border: '1px solid rgba(197,168,128,0.35)' }}>
          <h3 className="text-gradient m-0 mb-8">{t('staffDashboard.billingYourPlan')}</h3>
          <div className="dash-plan-badges">
            <span className={`dash-plan-badge dash-plan-${plan.plan}`}>{plan.plan.toUpperCase()}</span>
            <span className={`dash-plan-badge dash-plan-status-${plan.status}`}>{t(`staffDashboard.billingStatus_${plan.status}`, plan.status)}</span>
          </div>
          {plan.last_payment_date && (
            <p className="text-muted m-0 mt-8">{t('staffDashboard.billingLastPayment', { date: new Date(plan.last_payment_date).toLocaleDateString() })}</p>
          )}
          {plan.plan === 'free' && plan.trialDaysLeft != null && (
            <p className="text-muted m-0 mt-8">{t('staffDashboard.billingTrialDays', { days: plan.trialDaysLeft })}</p>
          )}
          {plan.status !== 'active' && (
            <div className="flex flex-wrap gap-16 mt-16">
              <button className="dash-btn dash-btn-success" onClick={() => subscribeToPlan('pro', provider)}>{t('staffDashboard.billingPlanPro')}</button>
              <button className="dash-btn dash-btn-success" onClick={() => subscribeToPlan('enterprise', provider)}>{t('staffDashboard.billingPlanEnterprise')}</button>
            </div>
          )}
        </div>
      ) : (
        <div className="glass-panel mb-20 p-20" style={{ border: '1px solid rgba(197,168,128,0.35)' }}>
          <h3 className="text-gradient m-0 mb-8">{t('staffDashboard.billingYourPlan')}</h3>
          <p className="text-muted m-0 mb-14">{t('staffDashboard.notAvailable')}</p>
          <div className="flex flex-wrap gap-16 mt-16">
            <button className="dash-btn dash-btn-success" onClick={() => subscribeToPlan('pro', provider)}>{t('staffDashboard.billingPlanPro')}</button>
            <button className="dash-btn dash-btn-success" onClick={() => subscribeToPlan('enterprise', provider)}>{t('staffDashboard.billingPlanEnterprise')}</button>
          </div>
        </div>
      )}
      <div className="flex-between gap-16 mb-18">
        <div>
          <h3 className="m-0">{t('staffDashboard.billingTitle')}</h3>
          <p className="text-muted m-0 mt-6">{t('staffDashboard.billingDescription')}</p>
        </div>
        <button className="dash-btn dash-btn-success" onClick={() => loadInvoices()}>{t('staffDashboard.billingRefresh')}</button>
      </div>
      {invoices.length === 0 ? (
        <div className="dash-empty-state glass-panel">
          <h3 className="text-gradient">{t('staffDashboard.billingEmptyTitle')}</h3>
          <p>{t('staffDashboard.billingEmptyMessage')}</p>
        </div>
      ) : (
        <div className="dash-table-responsive overflow-x-auto">
          <table className="dash-invoice-table table-full">
            <thead>
              <tr>
                <th className="table-cell-left">{t('staffDashboard.invoiceTableNumber')}</th>
                <th className="table-cell-right">{t('staffDashboard.invoiceTableAmount')}</th>
                <th className="table-cell-left">{t('staffDashboard.invoiceTableDue')}</th>
                <th className="table-cell-left">{t('staffDashboard.invoiceTableStatus')}</th>
                <th className="table-cell-center">{t('staffDashboard.invoiceTableAction')}</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id}>
                  <td className="table-cell-pad">#{inv.id}</td>
                  <td className="table-cell-pad-right">${inv.amount}</td>
                  <td className="table-cell-pad">{inv.due_date}</td>
                  <td className="table-cell-pad"><span className={`dash-appointment-status dash-status-${inv.status}`}>{inv.status}</span></td>
                  <td className="table-cell-pad-center">
                    {inv.status === 'pending' && (
                      <button className="dash-btn dash-btn-success" onClick={() => handlePayInvoice(inv.id, provider)}>{t('staffDashboard.invoicePayButton')}</button>
                    )}
                    <button className="dash-btn" onClick={() => exportInvoicePdf(inv, settings)}>{t('staffDashboard.invoiceDownloadPdf')}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
