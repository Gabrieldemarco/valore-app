import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import PublicIndex from './PublicIndex';
import * as apiClient from '../../api/client';
import { ThemeProvider } from '../../contexts/ThemeContext';

const mockSalons = {
  tenants: [
    { id: 1, business_name: 'Barbería Clásica', slug: 'barberia-clasica', business_address: 'Centro', landing_description: 'Cortes clásicos', brand_logo_url: null, landing_hero_image: null, services: [{ name: 'Corte' }, { name: 'Barba' }] },
    { id: 2, business_name: 'Salón Elegance', slug: 'salon-elegance', business_address: 'Punta Carretas', landing_description: 'Estética femenina', brand_logo_url: '/uploads/logo.png', landing_hero_image: null, services: [{ name: 'Tintura' }, { name: 'Peinado' }] },
    { id: 3, business_name: 'Unisex Moderno', slug: 'unisex-moderno', business_address: 'Tres Cruces', landing_description: 'Cortes modernos y color', brand_logo_url: null, landing_hero_image: null, services: [] },
  ],
};

function renderPublicIndex(salonResponse?: object) {
  const spy = vi.spyOn(apiClient.api, 'get');
  if (salonResponse !== undefined) {
    spy.mockImplementation((path: string) => {
      if (path === '/api/geo') return Promise.resolve({ country: 'Uruguay', countryCode: 'UY' });
      return Promise.resolve(salonResponse);
    });
  } else {
    spy.mockImplementation((path: string) => {
      if (path === '/api/geo') return Promise.resolve({ country: 'Uruguay', countryCode: 'UY' });
      return new Promise(() => {}); // never resolve (loading state)
    });
  }
  return render(<MemoryRouter><ThemeProvider><PublicIndex /></ThemeProvider></MemoryRouter>);
}

beforeEach(() => {
  vi.clearAllMocks();
  Element.prototype.scrollIntoView = vi.fn();
});

describe('PublicIndex', () => {
  it('shows loading state initially', () => {
    renderPublicIndex(); // no response = loading
    expect(screen.getByText('Cargando peluquerías...')).toBeInTheDocument();
  });

  it('shows error state on API failure', async () => {
    const spy = vi.spyOn(apiClient.api, 'get');
    spy.mockImplementation((path: string) => {
      if (path === '/api/geo') return Promise.resolve({ country: 'Uruguay', countryCode: 'UY' });
      return Promise.reject(new Error('Network error'));
    });
    render(<MemoryRouter><ThemeProvider><PublicIndex /></ThemeProvider></MemoryRouter>);
    await waitFor(() => {
      expect(screen.getByText('No pudimos cargar las peluquerías.')).toBeInTheDocument();
    });
  });

  it('shows empty state when no salons match filter', async () => {
    renderPublicIndex({ tenants: [] });
    await waitFor(() => {
      expect(screen.getByText(/No se encontraron resultados/)).toBeInTheDocument();
    }, { timeout: 3000 });
  });

  it('renders salon cards after loading', async () => {
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getAllByText('Barbería Clásica').length).toBeGreaterThanOrEqual(1);
    });
    expect(screen.getAllByText('Salón Elegance').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Unisex Moderno').length).toBeGreaterThanOrEqual(1);
  });

  it('displays salon address and services', async () => {
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getAllByText('Centro').length).toBeGreaterThanOrEqual(1);
    });
    expect(screen.getAllByText('Corte').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Barba').length).toBeGreaterThanOrEqual(1);
  });

  it('shows initials fallback when no image', async () => {
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      const initials = document.querySelector('.salon-initials');
      expect(initials).toBeInTheDocument();
      expect(screen.getAllByText('BC').length).toBeGreaterThanOrEqual(1);
    });
  });

  it('salon card links to correct URL', async () => {
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getAllByText('Barbería Clásica').length).toBeGreaterThanOrEqual(1);
    });
    const links = screen.getAllByRole('link');
    const salonLink = links.find(l => l.getAttribute('href') === '/p/barberia-clasica');
    expect(salonLink).toBeInTheDocument();
  });

  it('gender filter buttons are rendered and clickable', async () => {
    const user = userEvent.setup();
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getByText('Caballeros')).toBeInTheDocument();
    });
    expect(screen.getAllByText('Damas').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Unisex').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Todos').length).toBeGreaterThanOrEqual(1);
    const caballerosBtns = screen.getAllByText('Caballeros');
    const filterBtn = caballerosBtns.find(el => el.closest('button'));
    if (filterBtn) await user.click(filterBtn);
    await waitFor(() => {
      const allCaba = screen.getAllByText('Caballeros');
      const activeBtn = allCaba.find(el => el.closest('button')?.classList.contains('active'));
      expect(activeBtn).toBeTruthy();
    });
  });

  it('search filters salons by name', async () => {
    const user = userEvent.setup();
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getAllByText('Barbería Clásica').length).toBeGreaterThanOrEqual(1);
    });
    const searchInput = screen.getByPlaceholderText('Servicio');
    await user.type(searchInput, 'Elegance');
    await waitFor(() => {
      expect(screen.queryAllByText('Barbería Clásica').length).toBe(0);
    });
    expect(screen.getAllByText('Salón Elegance').length).toBeGreaterThanOrEqual(1);
  });

  it('hero collage click sets gender filter', async () => {
    const user = userEvent.setup();
    renderPublicIndex(mockSalons);
    await waitFor(() => {
      expect(screen.getAllByText('Barbería Clásica').length).toBeGreaterThanOrEqual(1);
    });
    const collageCards = document.querySelectorAll('.collage-card');
    expect(collageCards.length).toBe(2);
    if (collageCards[1]) await user.click(collageCards[1]);
    await waitFor(() => {
      expect(document.querySelector('.filter-btn.active')).toBeInTheDocument();
    });
  });

  it('renders hero section with title and subtitle', () => {
    renderPublicIndex(); // no response = loading
    const titles = screen.getAllByText(/Reservá servicios de belleza y bienestar|Reserva servicios de cuidado personal/i);
    expect(titles.length).toBeGreaterThanOrEqual(1);
    const subs = screen.getAllByText(/Encuentra los mejores establecimientos/i);
    expect(subs.length).toBeGreaterThanOrEqual(1);
  });

  it('has register and login links in header', () => {
    renderPublicIndex(); // no response = loading
    expect(screen.getByText('Sumate a Velsoie').closest('a')).toHaveAttribute('href', '/staff/register');
    expect(screen.getByText('Studio Access').closest('a')).toHaveAttribute('href', '/staff/login');
  });

  it('renders features section', () => {
    renderPublicIndex(); // no response = loading
    expect(screen.getByText('1. Buscá tu Peluquería')).toBeInTheDocument();
    expect(screen.getByText('2. Elegí el Servicio')).toBeInTheDocument();
    expect(screen.getByText('3. Confirmá en Segundos')).toBeInTheDocument();
  });
});
