import { useTranslation } from 'react-i18next';
import { PLACEHOLDER_IMG } from '../../utils/imageUtils';

interface TeamItem {
  name: string;
  specialties?: string[];
  role?: string;
  bio?: string | null;
  photo_url?: string | null;
  photo?: string;
}

interface StaffMember {
  id: number;
  name: string;
  photo_url: string | null;
  bio: string | null;
  specialties: string[];
}

interface LandingTeamSectionProps {
  team: TeamItem[];
  staff: StaffMember[];
  gallery: string[];
  fixImageUrl: (url: string | null | undefined) => string;
  onSelectStaff: (id: number) => void;
  onOpenLightbox: (idx: number) => void;
}

export default function LandingTeamSection({
  team,
  staff,
  gallery,
  fixImageUrl,
  onSelectStaff,
  onOpenLightbox,
}: LandingTeamSectionProps) {
  const { t } = useTranslation();
  return (
    <>
      {gallery.length > 0 && (
        <>
          <h2 className="section-title">{t('landingTeam.galleryTitle')}</h2>
          <p className="section-subtitle">{t('landingTeam.gallerySubtitle')}</p>
          <div className="gallery-grid">
            {gallery.map((g, i) => (
              <div key={i} className="gallery-item" onClick={() => onOpenLightbox(i)}>
                <img
                  src={fixImageUrl(g)}
                  alt=""
                  onError={e => { (e.target as HTMLImageElement).src = PLACEHOLDER_IMG; }}
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        </>
      )}

      {team.length > 0 && (
        <>
          <h2 className="section-title">{t('landingTeam.title')}</h2>
          <p className="section-subtitle">{t('landingTeam.subtitle')}</p>
          <div className="team-grid">
            {team.map((m, i) => {
              const staffMember = staff.find(s => s.name === m.name);
              const staffId = staffMember?.id || (m as StaffMember & { id?: number }).id;
              return (
                <div
                  key={i}
                  className="team-card"
                  style={staffId ? { cursor: 'pointer' } : undefined}
                  onClick={() => {
                    if (staffId) onSelectStaff(staffId);
                  }}
                >
                  {(m.photo_url || m.photo) && (
                    <img
                      src={fixImageUrl(m.photo_url || m.photo || '')}
                      alt={m.name}
                      className="team-photo"
                      onError={e => { (e.target as HTMLImageElement).src = PLACEHOLDER_IMG; }}
                      loading="lazy"
                    />
                  )}
                  <h3 className="team-name">{m.name}</h3>
                  {(m.specialties?.join(', ') || m.role) && (
                    <p className="team-role">{m.specialties?.join(', ') || m.role}</p>
                  )}
                  {m.bio && <p className="team-bio">{m.bio}</p>}
                </div>
              );
            })}
          </div>
        </>
      )}
    </>
  );
}
