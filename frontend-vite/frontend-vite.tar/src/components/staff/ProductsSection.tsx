import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { api } from '../../api/client';
import { logger } from '../../services/logger';
import ImageCropModal from '../ImageCropModal';

interface ProductItem {
  id: number; name: string; description: string; price: number; cost: number;
  stock: number; min_stock: number; category: string; sku: string; image_url: string;
  active: boolean; created_at: string;
}

interface ProductsSectionProps {
  products: ProductItem[];
  addToast: (message: string, type: 'success' | 'error') => void;
  refreshProducts: () => Promise<void>;
}

export default function ProductsSection({ products, addToast, refreshProducts }: ProductsSectionProps) {
  const { t } = useTranslation();
  const [productsForm, setProductsForm] = useState({ name: '', description: '', price: '0', cost: '0', stock: '0', min_stock: '0', category: '', sku: '', image_url: '' });
  const [productsModal, setProductsModal] = useState<{ open: boolean; editing: ProductItem | null }>({ open: false, editing: null });
  const [productCropFile, setProductCropFile] = useState<File | null>(null);
  const [productCropAspect, setProductCropAspect] = useState(1 / 1);

  const openProductCreate = () => {
    setProductsForm({ name: '', description: '', price: '0', cost: '0', stock: '0', min_stock: '0', category: '', sku: '', image_url: '' });
    setProductsModal({ open: true, editing: null });
  };

  const openProductEdit = (p: ProductItem) => {
    setProductsForm({ name: p.name, description: p.description, price: String(p.price), cost: String(p.cost), stock: String(p.stock), min_stock: String(p.min_stock), category: p.category, sku: p.sku, image_url: p.image_url || '' });
    setProductsModal({ open: true, editing: p });
  };

  const handleProductImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProductCropFile(file);
    setProductCropAspect(1 / 1);
  };

  const handleProductCropApply = async (dataUrl: string) => {
    if (!productCropFile) return;
    try {
      const res = await api.post<{ success: boolean; url: string; message: string }>('/api/upload-image', { image: dataUrl, filename: `product-${Date.now()}.jpg` });
      if (res.success && res.url) {
        setProductsForm(p => ({ ...p, image_url: res.url }));
        addToast(t('staffDashboard.toastProductImageUploadSuccess'), 'success');
      } else {
        addToast(t('staffDashboard.toastProductImageUploadError'), 'error');
      }
    } catch {
      logger.error('Error uploading product image:', productCropFile.name);
      addToast(t('staffDashboard.toastProductImageUploadError'), 'error');
    }
    setProductCropFile(null);
  };

  const saveProduct = async () => {
    if (!productsForm.name || !productsForm.price) { addToast(t('staffDashboard.toastProductSaveValidation'), 'error'); return; }
    try {
      const body = { name: productsForm.name, description: productsForm.description, price: parseFloat(productsForm.price), cost: parseFloat(productsForm.cost), stock: parseInt(productsForm.stock, 10), min_stock: parseInt(productsForm.min_stock, 10), category: productsForm.category, sku: productsForm.sku, image_url: productsForm.image_url };
      if (productsModal.editing) {
        await api.put(`/api/tenant/products/${productsModal.editing.id}`, body);
        addToast(t('staffDashboard.toastProductUpdated'), 'success');
      } else {
        await api.post('/api/tenant/products', body);
        addToast(t('staffDashboard.toastProductCreated'), 'success');
      }
      setProductsModal({ open: false, editing: null });
      setProductCropFile(null);
      refreshProducts();
    } catch (e: unknown) { addToast(e instanceof Error ? e.message : t('staffDashboard.toastProductSaveError'), 'error'); }
  };

  const deleteProduct = async (id: number, name: string) => {
    if (!confirm(t('staffDashboard.toastProductDeleteConfirm', { name }))) return;
    try {
      await api.delete(`/api/tenant/products/${id}`);
      addToast(t('staffDashboard.toastProductDeleted'), 'success');
      refreshProducts();
    } catch { addToast(t('staffDashboard.toastProductDeleteError'), 'error'); }
  };

  return (
    <>
      <div className="glass-panel section-card">
        <div className="flex-between mb-20">
          <h3 className="text-gradient m-0">{t('staffDashboard.tabProducts')}</h3>
          <button className="dash-btn dash-btn-success" onClick={openProductCreate}>{t('staffDashboard.productsNewButton')}</button>
        </div>
        {products.length === 0 ? (
          <div className="dash-empty-state glass-panel">
            <h4>{t('staffDashboard.servicesEmptyTitle')}</h4>
            <p>{t('staffDashboard.servicesEmptyMessage')}</p>
          </div>
        ) : (
          <div className="dash-table-responsive table-wrapper">
            <table className="table-full">
              <thead>
                <tr>
                  <th className="table-cell-left">{t('staffDashboard.servicesTableName')}</th>
                  <th className="table-cell-center">{t('staffDashboard.productsTableImage')}</th>
                  <th className="table-cell-left">{t('staffDashboard.productsTableCategory')}</th>
                  <th className="table-cell-right">{t('staffDashboard.productsTablePrice')}</th>
                  <th className="table-cell-right">{t('staffDashboard.productsTableCost')}</th>
                  <th className="table-cell-right">{t('staffDashboard.productsTableStock')}</th>
                  <th className="table-cell-center">{t('staffDashboard.servicesTableActive')}</th>
                  <th className="table-cell-center">{t('staffDashboard.staffTableActions')}</th>
                </tr>
              </thead>
              <tbody>
                {products.map(p => (
                  <tr key={p.id}>
                    <td className="table-cell-label">{p.name}</td>
                    <td className="table-cell-pad-center">
                      {p.image_url ? (
                        <img src={p.image_url} alt="" className="w-40 h-40 object-cover-4" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <span className="text-muted opacity-50">—</span>
                      )}
                    </td>
                    <td className="p-12 text-muted">{p.category || '-'}</td>
                    <td className="table-cell-pad-right">${p.price}</td>
                    <td className="table-cell-pad-right text-muted">${p.cost}</td>
                    <td className="table-cell-pad-right">
                      <span style={{ color: p.stock <= p.min_stock ? 'var(--danger-light)' : 'var(--text-secondary)' }}>{p.stock}</span>
                      {p.min_stock > 0 && <span className="fs-12 text-secondary ml-4">/ {p.min_stock}</span>}
                    </td>
                    <td className="table-cell-pad-center">
                      <span className={`dash-appointment-status ${p.active ? 'dash-status-confirmed' : 'dash-status-cancelled'}`}>
                        {p.active ? t('staffDashboard.servicesYes') : t('staffDashboard.servicesNo')}
                      </span>
                    </td>
                    <td className="table-cell-pad-center">
                      <button className="dash-btn dash-btn-success" onClick={() => openProductEdit(p)}>{t('staffDashboard.servicesEditButton')}</button>
                      <button className="dash-btn dash-btn-danger" onClick={() => deleteProduct(p.id, p.name)}>{t('staffDashboard.servicesDeleteButton')}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {productsModal.open && (
        <div className="dash-modal-overlay flex" onClick={() => setProductsModal({ open: false, editing: null })}>
          <div className="dash-modal-content glass-panel max-w-500" onClick={e => e.stopPropagation()}>
            <div className="dash-modal-header">
              <h3 className="text-gradient">{productsModal.editing ? t('staffDashboard.productsModalEditTitle') : t('staffDashboard.productsModalNewTitle')}</h3>
              <button onClick={() => setProductsModal({ open: false, editing: null })} className="dash-close-btn">✕</button>
            </div>
            <div className="dash-modal-body">
              <div className="dash-form-group">
                <label>{t('staffDashboard.productsModalNameLabel')}</label>
                <input type="text" className="glass-input" value={productsForm.name} onChange={e => setProductsForm(p => ({ ...p, name: e.target.value }))} placeholder={t('staffDashboard.productsModalNamePlaceholder')} />
              </div>
              <div className="dash-form-group">
                <label>{t('staffDashboard.productsModalDescriptionLabel')}</label>
                <textarea className="glass-input" value={productsForm.description} onChange={e => setProductsForm(p => ({ ...p, description: e.target.value }))} placeholder={t('staffDashboard.productsModalDescriptionPlaceholder')} />
              </div>
              <div className="grid-2-sm">
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalPriceLabel')}</label>
                  <input type="number" className="glass-input" value={productsForm.price} onChange={e => setProductsForm(p => ({ ...p, price: e.target.value }))} min="0" step="0.01" />
                </div>
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalCostLabel')}</label>
                  <input type="number" className="glass-input" value={productsForm.cost} onChange={e => setProductsForm(p => ({ ...p, cost: e.target.value }))} min="0" step="0.01" />
                </div>
              </div>
              <div className="grid-2-sm">
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalStockLabel')}</label>
                  <input type="number" className="glass-input" value={productsForm.stock} onChange={e => setProductsForm(p => ({ ...p, stock: e.target.value }))} min="0" />
                </div>
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalMinStockLabel')}</label>
                  <input type="number" className="glass-input" value={productsForm.min_stock} onChange={e => setProductsForm(p => ({ ...p, min_stock: e.target.value }))} min="0" />
                </div>
              </div>
              <div className="grid-2-sm">
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalSKULabel')}</label>
                  <input type="text" className="glass-input" value={productsForm.sku} onChange={e => setProductsForm(p => ({ ...p, sku: e.target.value }))} placeholder={t('staffDashboard.productsModalSKUPlaceholder')} />
                </div>
                <div className="dash-form-group">
                  <label>{t('staffDashboard.productsModalCategoryLabel')}</label>
                  <input type="text" className="glass-input" value={productsForm.category} onChange={e => setProductsForm(p => ({ ...p, category: e.target.value }))} placeholder={t('staffDashboard.productsModalCategoryPlaceholder')} />
                </div>
              </div>
              <div className="dash-form-group">
                <label>{t('staffDashboard.productsModalImageLabel')}</label>
                <input type="text" className="glass-input" value={productsForm.image_url} onChange={e => setProductsForm(p => ({ ...p, image_url: e.target.value }))} placeholder={t('staffDashboard.productsModalImagePlaceholder')} />
                <input type="file" accept="image/*" className="glass-input fs-13 mt-6 p-6" onChange={handleProductImageUpload} />
                {productsForm.image_url && (
                  <div className="mt-6">
                    <img src={productsForm.image_url} alt="" className="w-60 h-60 object-cover-6" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  </div>
                )}
              </div>
              <div className="flex flex-gap-12 mt-8 flex-end">
                <button className="dash-btn dash-btn-danger" onClick={() => setProductsModal({ open: false, editing: null })}>{t('staffDashboard.productsModalCancel')}</button>
                <button className="dash-btn dash-btn-success" onClick={saveProduct}>{productsModal.editing ? t('staffDashboard.productsModalSave') : t('staffDashboard.productsModalCreate')}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {productCropFile && (
        <ImageCropModal
          open={true}
          file={productCropFile}
          aspectRatio={productCropAspect}
          onApply={(dataUrl) => handleProductCropApply(dataUrl)}
          onCancel={() => setProductCropFile(null)}
        />
      )}
    </>
  );
}
