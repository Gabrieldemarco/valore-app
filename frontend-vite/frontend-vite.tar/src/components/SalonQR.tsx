import { useRef, useCallback, useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { X, Share2, Download, Check } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface Props {
  slug: string;
  onClose: () => void;
}

export default function SalonQR({ slug, onClose }: Props) {
  const { t } = useTranslation();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}/p/${slug}`;

  const cssVar = (name: string, fallback: string) =>
    getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
  const bgColor = cssVar('--bg-deep', '#120c0c');
  const fgColor = cssVar('--primary', '#c8827d');

  const download = useCallback(() => {
    const canvas = canvasRef.current?.querySelector('canvas');
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `valore-${slug}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }, [slug]);

  const copyLink = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch { /* silent */ }
  }, [url]);

  const share = useCallback(async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: t('salonQR.shareTitle'),
          text: t('salonQR.shareText'),
          url,
        });
        return;
      } catch { /* user cancelled or error */ }
    }
    await copyLink();
  }, [t, url, copyLink]);

  const canShare = typeof navigator.share === 'function';

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 99999, display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)',
      padding: 20,
    }} onClick={onClose}>
      <div className="glass-panel w-full p-32 max-w-340" onClick={e => e.stopPropagation()}>
        <div className="flex-between mb-20">
          <h3 className="text-gradient m-0 fs-19">{t('salonQR.title')}</h3>
          <button onClick={onClose} className="dash-close-btn" style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 21, cursor: 'pointer' }}><X size={20} /></button>
        </div>
        <div className="text-center">
          <div ref={canvasRef}>
            <QRCodeCanvas value={url} size={200} bgColor={bgColor} fgColor={fgColor} level="M" />
          </div>
          <div className="flex-center-center gap-10 flex-wrap mt-20">
            <button onClick={download} className="dash-btn dash-btn-primary fs-14 px-18 py-8">
              <Download size={14} className="mr-8 vertical-align-middle" />{t('salonQR.downloadButton')}
            </button>
            <button onClick={share} className="dash-btn btn btn-secondary fs-14 px-18 py-8 no-underline">
              {copied
                ? <><Check size={14} className="mr-8 vertical-align-middle" />{t('salonQR.linkCopied')}</>
                : <><Share2 size={14} className="mr-8 vertical-align-middle" />{canShare ? t('salonQR.shareButton') : t('salonQR.copyLinkButton')}</>}
            </button>
          </div>
          <p className="text-muted fs-14 mt-16 word-break-all">{url}</p>
        </div>
      </div>
    </div>
  );
}
